pdfs are stored in a folder called Hands, located in the same direcotry of the executable

cardimages folder needs to be located in the same directory as the app excecutable